"""Python code to replace value and reshape matrix ."""

# Created By  : "Sarita Yadav "
# Created Date: "12-08-2020 "



filename="C:/csvoutput/data.txt" # Specify Filename

def get_data(finename):
    """
    Getting matrix data from file .
    :param finename:
    :return: data element
    """
    with open (filename,encoding='utf-8') as file_object:  # read the .txt file
        lines=file_object.read()
        rows=lines.replace('@','')  # replace special character with ''
    return rows


def reshape_matrix(filename):
    """
    reshaping matrix after replacing int
    values with string.
    :param filename:
    :return:
    """
    rows = get_data(filename)
    sring_new=''
    for line in rows:
        sring_new+=line.rstrip()
    res_list = [x[0] for x in sring_new]
    clean=res_list[3:-2]  # select only required list of values and ommit special characters

    reshape_mat=[clean[i:i+6] for i in range(0,len(clean),6)] # reshape list to 6X6 matrix

    for number in [reshape_mat]:  # replace and add corner values
        number[0][2]=number[1][2]
        number[0][4]=number[1][4]
        number[2][0]=number[1][0]
        number[4][3]=number[0][0]+number[0][5]+number[5][0]+number[5][5]
        print(reshape_mat)
        print("Updated matrix :: {}".format(reshape_mat))
    return reshape_mat





if __name__ == '__main__':
    reshape_matrix(filename)







