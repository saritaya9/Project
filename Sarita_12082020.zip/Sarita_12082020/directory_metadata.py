"""Python code to get all files data from directory and export in csv ."""

# =============================================================================
# Created By  : "Sarita Yadav "
# Created Date: "12-08-2020 "



# Built-in/Generic Imports
import os
import enum
import time
import stat
import pandas as pd




class SIZE_UNIT(enum.Enum):
   BYTES = 1
   KB = 2
   MB = 3
   GB = 4


def convert_unit(size_in_bytes, unit):

   """
   Convert the size from bytes to other units like KB, MB or GB
   :param size_in_bytes:
   :param unit:
   :return: size_in_byte
   """

   if unit == SIZE_UNIT.KB:
       return size_in_bytes/1024
   elif unit == SIZE_UNIT.MB:
       return size_in_bytes/(1024*1024)
   elif unit == SIZE_UNIT.GB:
       return size_in_bytes/(1024*1024*1024)
   else:
       return size_in_bytes


def get_file_size(filepath):
   stat_info  = os.stat(filepath)
   size = stat_info.st_size
   return convert_unit(size, SIZE_UNIT.KB)



def get_lst_modifiedtime(filepath):

    """
    Getting last modified date along with month and time
    :param filepath:
    :return: modificationTime
    """

    fileStatsObj = os.stat(filepath)
    modificationTime = time.ctime(fileStatsObj[stat.ST_MTIME])
    return modificationTime


def get_createdtime(filepath):

    """ Getting creation time of file in the directory"""
    created_time = time.ctime(os.path.getctime(filepath))
    return created_time



def get_metadata(path):
    """
    This function will take path as input param and return CSV of metadata
    :param path:
    :return: dataFrame output in csv
    """
    with os.scandir(path) as listOfEntries:
        filename = []
        filesize =[]
        created_date = []
        modified_date = []
        filetype =[]

        for entry in listOfEntries:
            if entry.is_file():
                file_name = entry.name
                name, ext = os.path.splitext(file_name)
                filename.append(name)
                filetype.append(ext.replace(".", ""))
                file_path = path+"/"+file_name
                size = round(get_file_size(file_path))
                filesize.append(size)
                created_time = get_createdtime(file_path)
                created_date.append(created_time)
                lastmodify_time = get_lst_modifiedtime(file_path)
                modified_date.append(lastmodify_time)


        data = {'filename': filename, "Last Modified Date":lastmodify_time,
                "filetype":filetype,"filesize [KB]": filesize,"Creation Date":created_time }
        df = pd.DataFrame(data)
        df.to_csv("C:/csvoutput/metadata.csv", index=False)
        print("Updated response in csv")





directory_path = "C:/Projects/Documents/docs"

if __name__ == '__main__':
    get_metadata(directory_path)
